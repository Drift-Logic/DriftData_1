# DriftData: Annotated Persuasive Essay Dataset Usage Guide

This guide walks through basic usage of the DriftData Annotated Persuasive Essay Dataset for NLP training, argument mining, and structure-aware modeling.

---

## Loading the Data

Each file in `data/` is a single JSON object representing a synthetic essay:

```python
import json
from pathlib import Path

data_dir = Path("data")
essays = [json.loads(f.read_text()) for f in data_dir.glob("*.json")]
```

Each `essay` will contain:
- `origin_text`: the raw essay
- `argument_units_clean`: labeled spans (major_claim, claim, premise)
- `relations`: dictionary mapping argument relationships (supports, attacks)

---

## Example Use Cases

### 1. Token Classification with Hugging Face
Use `argument_units_clean` to train a BIO tagger for identifying argumentative spans.

### 2. Span-Based Relation Modeling
Use the `relations` dictionary and span embeddings to train a classifier predicting links (support/attack) between units.

### 3. Fine-Tuning a Model
Fine-tune any transformer model using this structured data for downstream tasks like essay scoring, structure extraction, or claim detection.

---

## Additional Resources

- `schema.md`: Overview of all fields in each essay JSON
- `benchmark_results.md`: Shows how this data compares to real-world annotated corpora
- `DriftLogic_Commercial_Dataset_License_v1.0.txt`: Terms of use

---

## Need Help?

Email us at [founder@driftlogic.ai](mailto:founder@driftlogic.ai) or visit [driftlogic.ai](https://driftlogic.ai) for support or custom integration options.
