# DriftData: Annotated Persuasive Essay Dataset Changelog

This file documents changes, updates, and improvements to DriftData synthetic dataset releases.

---

## [1.0.0] – 2025-07-12

Initial release of DriftData: Annotated Persuasive Essay Dataset

- 1500 total annotated synthetic persuasive essays
- Includes Set 1 (750), Set 2 (750), and Sample (150)
- Structured annotations for major claims, claims, and premises
- Relation annotations for argument structure (supports, attacks)
- Research License (CC BY-NC 4.0): Sample, Set 1, and Set 2 
- DriftLogic Commercial License: Pro Bundle
- Benchmark comparison against real essay datasets

---

## Planned / Upcoming

> These are roadmap notes, not guarantees.

- Clause structured datasets
- New datasets with additional domain/topic variations (e.g., legal, medical, opinion)
- Multilingual synthetic argument datasets (DE, FR, ES, etc.)
- Argument-to-essay generation dataset (structured → natural language)
- Persuasive quality argument datasets
