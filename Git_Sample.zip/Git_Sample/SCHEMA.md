# DriftData: Annotated Persuasive Essay Dataset Schema (v1.0)

This document outlines the structure of each essay file in the DriftData Annotated Persuasive Essay Dataset.

## Format

Each file is a JSON object representing a single synthetic essay with structured argument annotations.

### Top-Level Fields

| Field               | Type         | Description                                         |
|---------------------|--------------|-----------------------------------------------------|
| `origin_text`       | `string`     | The raw essay text (usually 250–500 words)         |
| `argument_units_clean` | `list[dict]` | Cleaned annotations for argumentative spans         |
| `relations`         | `dict`       | Mapping of argumentative relations (source → target)|

---

## `argument_units_clean`

Each unit is a dictionary with:

| Field     | Type             | Description                                      |
|-----------|------------------|--------------------------------------------------|
| `text`    | `string`         | The exact text span of the argument component   |
| `role`    | `string`         | One of `major_claim`, `claim`, or `premise`     |
| `offsets` | `tuple[int, int]`| Character index of span within `origin_text`    |

---

## `relations`

Top-level key is always `"root"`. Each item is:

| Field      | Type     | Description                              |
|------------|----------|------------------------------------------|
| `source`   | `string` | Text of the source span                  |
| `target`   | `string` | Text of the target span                  |
| `relation` | `string` | Either `"supports"` or `"attacks"`      |

---

## Example

```json
{
  "origin_text": "Some believe school uniforms reduce violence. I disagree. Uniforms do not address the root causes...",
  "argument_units_clean": [
    {"text": "Some believe school uniforms reduce violence", "role": "claim", "offsets": [0, 46]},
    {"text": "I disagree", "role": "major_claim", "offsets": [48, 58]},
    {"text": "Uniforms do not address the root causes", "role": "premise", "offsets": [60, 104]}
  ],
  "relations": {
    "root": [
      {"source": "Uniforms do not address the root causes", "target": "I disagree", "relation": "supports"}
    ]
  }
}
```
